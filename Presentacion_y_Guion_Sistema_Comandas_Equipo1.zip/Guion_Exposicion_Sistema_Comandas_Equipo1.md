# Guion para exponer: Sistema de Comandas

## Cómo usar el material

La presentación breve contiene 30 diapositivas; la completa contiene 50. Las siguientes notas acompañan la versión breve. Ensayen con la copia del sistema y no afirmen que existe una evidencia que no se revisó.

## Diapositiva 1: Portada (original 1)

Juan abre: “Nuestro proyecto es un sistema de comandas de restaurante. Lo importante para esta evaluación es explicar cómo nos organizamos, qué aportó cada integrante, cómo usamos Jira y cómo fuimos construyendo el sistema en cuatro sprints.”

## Diapositiva 2: Qué evaluará el profesor (original 2)

Juan: “El profesor nos explicó que evaluará principalmente la metodología. Por eso nuestra presentación se centra en planeación, responsabilidades, seguimiento, problemas y aprendizaje. El código funciona como evidencia, no como el único criterio.”

## Diapositiva 3: El sistema en una mirada (original 3)

Juan explica el objetivo: “La aplicación usa perfiles distintos. Un mesero no debería cobrar y un cajero no debería administrar inventario. A través de los sprints fuimos agregando estas partes”.

## Diapositiva 4: Los cinco integrantes (original 4)

Juan: “Yo fui Scrum Master: ayudé a coordinar, integrar y dar seguimiento. El profesor asumirá Product Owner en esta evaluación. Los demás compañeros realizaron sus tareas asignadas y se coordinaron para conectarlas. En documentos antiguos Javier aparece como Product Owner interno, pero aquí usamos el rol que estableció el profesor”.

## Diapositiva 5: Ruta de cuatro sprints (original 6)

Juan: “No empezamos por los reportes. Primero necesitábamos usuarios y permisos, luego productos y pedidos, después cobro e inventario y finalmente datos históricos y mejoras visuales. Este orden se ve en las dependencias documentadas”.

## Diapositiva 6: Tareas T1–T8 (original 8)

Explica: “T1 y T5 fueron de Juan; T2 de Javier; T3 y T7 de Pato; T4 y T8 de Said; T6 de Aarón. Las tareas se encadenan: usuario, contraseña, validación, rol, menú y empleados”. No afirmar estados finales actuales de Jira sin mostrar el tablero.

## Diapositiva 7: Login y roles (original 9)

Said: “Aquí se ingresa el usuario y contraseña. La función valida las credenciales y determina el rol.” Juan: “Cada rol tiene un conjunto diferente de opciones. La pantalla de mesero no es la misma que la de gerente”.

## Diapositiva 8: Empleados y usuarios (original 10)

Said: “El alta de usuarios estaba planificada desde el Sprint 1. Con el tiempo mejoramos la pantalla de empleados. Si una cuenta se desactiva, se conserva en SQLite pero no puede iniciar sesión. En Sprint 4 corregimos el problema de volver a activarla”.

## Diapositiva 9: Tareas T9–T16 (original 13)

Javier explica T11, T12 y T14: listado, registro y disponibilidad de productos. Juan explica T9, T10 y T15. Pato explica T16 registrar mesas. Aarón puede referirse a T13 edición de productos.

## Diapositiva 10: Tareas T17–T24 (original 14)

Pato: “T17 muestra libre y ocupada; T18 abre pedido.” Aarón: “T19 agrega productos, T20 permite modificarlos y T21 los envía a cocina.” Javier: “T24 marca en preparación.” T22/T23 figuran como integración compartida en el manual consolidado, aunque una guía inicial los preveía para Pato.

## Diapositiva 11: Catálogo de productos (original 15)

Javier: “Se registran los productos con nombre, categoría y precio; los que no están disponibles pueden ocultarse para pedidos nuevos, pero se conservan en catálogo.” Un ejemplo visible: pizza y coca. El producto se guarda en SQLite, no en una lista fija en main.py.

## Diapositiva 12: Crear un pedido (original 17)

Aarón: “Primero se selecciona una mesa libre. Luego aparece el pedido en borrador, donde el mesero agrega productos y notas. Mientras está en borrador puede editarse; cuando se confirma y envía a cocina, cambia su estado y ya no se modifica de la misma manera”.

## Diapositiva 13: Tareas T25–T34 (original 20)

Aarón explica listo/entregado T25-T27. Juan explica consumos, totales, cuentas y cierre T28-T30/T34. Javier explica cobro, cambio y ticket T31-T33. El pago en SQLite es una operación local de registro; no equivale a procesar un pago bancario real.

## Diapositiva 14: Tareas T35–T44 (original 21)

Said presenta catálogo de insumos, existencias, mínimos y entradas; Pato salidas, actualización, alertas y órdenes; Javier proveedores; Aarón solicitud y recepción. La recepción de compra modifica inventario, por eso debe evitar duplicar entradas.

## Diapositiva 15: Caja y cierre (original 23)

Javier: “La caja recibe la cuenta de una mesa cuyos pedidos fueron entregados. Si paga en efectivo, calcula cambio; si paga con tarjeta, registra el método.” Juan: “Una vez cobrada y cerrada, la mesa puede volver a Libre”.

## Diapositiva 16: Insumos y compras (original 24)

Said: “Aquí creamos los insumos y definimos cantidad y mínimo.” Javier: “El proveedor se registra antes de una orden.” Pato/Aarón: “Las órdenes permiten solicitar y recibir insumos; al recibir se actualiza el inventario, evitando sumar dos veces”.

## Diapositiva 17: Tareas T45–T54 (original 27)

Juan introduce ventas y resumen. Javier consulta periodos y mejora caja/ticket. Aarón aporta historial de pagos. Said agrega búsqueda y detalle. Recuerda que el total de un pago puede abarcar varios pedidos; no confundirlo con el total de uno solo.

## Diapositiva 18: Tareas T55–T64 (original 28)

Javier completa reportes T55. Pato mejora inventario, alertas, compras y estilos T56-58/T63. Aarón actualiza pedidos y cocina T59-61. Said rediseña login y empleados T62/T64, incluida la mejora posterior para reactivar cuentas.

## Diapositiva 19: Pedidos y cocina por tarjetas (original 30)

Aarón: “En pedidos se muestran productos y cantidades. Cocina se organiza en columnas Pendiente, En preparación y Listo. T61 añade el cálculo de minutos desde envío, pero pedidos antiguos sin hora registrada necesitan tratamiento especial”.

## Diapositiva 20: Reportes e historial (original 31)

Javier: “El reporte usa fecha de cierre de cuenta para que las ventas del día coincidan con los cierres.” Said: “El historial permite buscar por fecha de pago, mesa o folio y conocer más detalles. Depende de que existan pagos históricos”.

## Diapositiva 21: Inventario y alertas (original 32)

Pato: “El inventario ahora resume insumos registrados, mínimos y stock bajo. Los colores son para lectura, no cambian cantidades. La recepción de compras sigue en su flujo de Sprint 3. T63 aporta estilos compartidos a la aplicación”.

## Diapositiva 22: Flujo completo (original 33)

El equipo recorre las dependencias en voz alta: el producto necesita mesa y pedido; la cocina requiere envío; el pago requiere entrega; el cierre requiere cobro; y el historial requiere ventas/pagos guardados. Ningún módulo debe fingir datos de pasos anteriores.

## Diapositiva 23: Uso de Jira (original 34)

Juan: “Jira fue nuestro tablero de trabajo. Una tarea debería tener objetivo, responsable, criterios y evidencia. Los documentos que conservamos describen la planeación, pero no permiten asegurar en qué fecha exacta se cerró cada tarjeta de Jira”.

## Diapositiva 24: WhatsApp, GitHub e IA (original 35)

Explicar con transparencia: “No hicimos todo el código manualmente; usamos IA como apoyo para partes del desarrollo y de la integración. Nuestra responsabilidad fue organizar, entender, integrar y probar lo que presentamos”. No mentir si el profesor pregunta si escribimos cada línea.

## Diapositiva 25: Obstáculos reales (original 37)

Cada integrante elige un problema que conoce. No inventamos dificultades no documentadas. La confusión de mesa ocupada era un problema de uso del sistema; T47 tenía una dependencia real; la activación de empleados fue un ajuste funcional; y WhatsApp complicó conservar una única versión.

## Diapositiva 26: Pruebas automáticas (original 38)

Juan: “Repetimos pruebas automáticas y aprobaron los casos ejecutados. Pero seguimos teniendo que comprobar visualmente todos los flujos y los datos de muestra. Tampoco hay una exportación final de Jira para afirmar que todas las tarjetas están cerradas”.

## Diapositiva 27: Buscar Coca/Pizza (original 40)

Respuesta modelo: “Esta sección corresponde a la gestión de productos, principalmente Javier (T11/T12) y Aarón (T13). La pantalla está en main.py, mostrar_productos; la consulta a SQLite en base_datos.py, listar_productos. Coca es un registro de datos, no una instrucción escrita a mano en el menú”.

## Diapositiva 28: Demostración sugerida (original 46)

Juan presenta el orden. Recomendar usar copia de restaurante.db y datos precreados. No limpiar la base real para acelerar una demostración. Cada paso requiere que el anterior se complete. Si no hay proveedores o insumos, no es momento de improvisar una compra.

## Diapositiva 29: Respuesta sobre IA (original 48)

Responder con naturalidad y transparencia. Si el profesor pregunta “¿tú escribiste el código?” decir qué partes aportó la persona, que se usó IA y que puede localizar y explicar su tarea. El método de trabajo y la revisión son responsabilidad humana, pero no atribuirse autoría manual de líneas generadas por IA.

## Diapositiva 30: Cierre (original 50)

Juan cierra: “Nuestro principal resultado no es solo una aplicación: es haber dividido el problema, organizado el trabajo, integrado los aportes de los cinco integrantes y aprendido a explicar y mejorar nuestro proceso. Gracias, profesor.”
